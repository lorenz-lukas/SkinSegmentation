Data obtained from

@inproceedings{casati_etal_SFA_wvc2013,
  title={{SFA}: A human skin image database based on {FERET} and {AR} facial images},
  author={Casati, Joao Paulo Brognoni and Moraes, Diego Rafael and Rodrigues, Evandro Luis Linhari},
  booktitle={{IX} Workshop de Visao Computational},
  address = {Rio de Janeiro, Brazil},
  year={2013},
  note={Dataset available at \url{http://www.sel.eesc.usp.br/sfa/}}
}
